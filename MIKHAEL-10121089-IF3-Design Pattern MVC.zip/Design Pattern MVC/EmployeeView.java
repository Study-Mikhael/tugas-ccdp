public class EmployeeView {
    public void printEmployeeDetails(String employeeName, String employeeRollNo, String employeePosition){
        System.out.println("Employee");
        System.out.println("Name : "+employeeName);
        System.out.println("Roll No. : "+employeeRollNo);
        System.out.println("Position : "+employeePosition);
    }
}